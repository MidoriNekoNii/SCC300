﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test1 : MonoBehaviour 
{
	public Dialogue dialogue;

	public void BeginIntro()
	{
		FindObjectOfType<AudioManager>().Play("Test1");	
	}

	public void BeginDialogue()
	{
		FindObjectOfType<DialogueManager>().StartDialogue(dialogue);
	}
}