﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow : MonoBehaviour 
{

	public Transform target;

	float speed = 10.0f;
	Vector3 lookDirection;
	const float EPSILON = 0.1f;

	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		lookDirection = (target.position - transform.position).normalized;
		if ((transform.position - target.position).magnitude > EPSILON)
		{
			transform.Translate(lookDirection * Time.deltaTime * speed);
		}
	}
}
