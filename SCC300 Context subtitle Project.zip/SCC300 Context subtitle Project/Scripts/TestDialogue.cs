﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TestDialogue : MonoBehaviour 
{
    private int xUpperBounds = -90;
    private int xLowerBounds = -360;

    private int yUpperBounds = -150;
    private int yLowerBounds = -250;

    private int xUpperBounds2 = 360;
    private int xLowerBounds2 = 90;

    private int yUpperBounds2 = -150;
    private int yLowerBounds2 = -250;

    public OffscreenIndicator indicators;
    public RectTransform rt;
    public RectTransform rt2;
    public Canvas canvas;
	public float smoothing = 1f;
    public float speed = 1f;
    public Vector3 velocity = Vector3.zero;

    public Vector3 target;
	public Vector3 Target
	{
		get { return target; }
		set
		{
			target = value;
		}
	}

    public Vector3 target2;
    public Vector3 Target2
    {
        get { return target2; }
        set
        {
            target2 = value;
        }
    }

    public Vector3 AnchoredPosition
    {
        get { return rt.anchoredPosition; }
        set
        {
            rt.anchoredPosition = value;
        }
    }

    public Vector3 AnchoredPosition2
    {
        get { return rt2.anchoredPosition; }
        set
        {
            rt2.anchoredPosition = value;
        }
    }

    public Vector3 subtitlePos1;
    public Vector3 subtitlePos2;

    void Start()
    {
       Target = indicators.OffscreenIndicatorPos;
       Target2 = indicators.OffscreenIndicatorPos2;
    }

    // Update is called once per frame
    void Update () 
	{
        //Debug.Log(rt.anchoredPosition.x + "," + rt.anchoredPosition.y);
        //controller(rt);
        //Debug.Log(rt2.anchoredPosition.x + "," + rt2.anchoredPosition.y);
        //controller(rt2);
        Target = indicators.OffscreenIndicatorPos;
        Target2 = indicators.OffscreenIndicatorPos2;
        trackSpeaker1();
        trackSpeaker2();
    }

    void trackSpeaker1()
    {
        //SPEAKER 1
        Vector3 diff = (Vector3) target - (Vector3) rt.anchoredPosition;
        Vector3 newPos = (Vector3) rt.anchoredPosition + (0.5f * Time.deltaTime * diff);
        rt.anchoredPosition = bounds(newPos, rt, xUpperBounds, xLowerBounds, yUpperBounds, yLowerBounds);
    }

    void trackSpeaker2()
    {
        //SPEAKER 2
        Vector3 diff2 = (Vector3)target2 - (Vector3) rt2.anchoredPosition;
        Vector3 newPos2 = (Vector3)rt2.anchoredPosition + (0.5f * Time.deltaTime * diff2);
        rt2.anchoredPosition = bounds(newPos2, rt2, xUpperBounds2, xLowerBounds2, yUpperBounds2, yLowerBounds2);
    }

    Vector3 bounds(Vector3 newPos, RectTransform rt, int xUpperBounds, int xLowerBounds, int yUpperBounds, int yLowerBounds)
    {
        //print("Target: " + target);
        //print("Subtitle: " + newPos);
        newPos.x = Mathf.Min(newPos.x + ((rt.rect.width * canvas.scaleFactor) / 2), xUpperBounds);
        newPos.y = Mathf.Min(newPos.y + ((rt.rect.height * canvas.scaleFactor) / 2), yUpperBounds);

        newPos.x = Mathf.Max(newPos.x - ((rt.rect.width * canvas.scaleFactor) / 2), xLowerBounds);
        //print(newPos.y + ((rt.rect.height * canvas.scaleFactor) / 2));
        newPos.y = Mathf.Max(newPos.y - ((rt.rect.height * canvas.scaleFactor) / 2), yLowerBounds);
        //print("Final Subtitle: " + newPos);
        return newPos;
    }

    void controller(RectTransform rt)
    {
        if (Input.GetKeyDown(KeyCode.I))
        {
            rt.anchoredPosition = new Vector2(rt.anchoredPosition.x, rt.anchoredPosition.y + 10f);
        }
        if (Input.GetKeyDown(KeyCode.K))
        {
            rt.anchoredPosition = new Vector2(rt.anchoredPosition.x, rt.anchoredPosition.y - 10f);
        }
        if (Input.GetKeyDown(KeyCode.J))
        {
            rt.anchoredPosition = new Vector2(rt.anchoredPosition.x - 10f, rt.anchoredPosition.y);
        }
        if (Input.GetKeyDown(KeyCode.L))
        {
            rt.anchoredPosition = new Vector2(rt.anchoredPosition.x + 10f, rt.anchoredPosition.y);
        }
    }
}