﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeColor : MonoBehaviour 
{
	public void OnEnable()
	{
		EventManager.ActionTriggered += ChangeTheColor;
	}

	public void OnDisable()
	{
		EventManager.ActionTriggered -= ChangeTheColor;
	}

	public void ChangeTheColor()
	{
		Color col = new Color (Random.value, Random.value, Random.value);
		transform.GetComponent<Renderer>().material.color = col;
	}
}