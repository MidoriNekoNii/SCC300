﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Speaker : MonoBehaviour 
{
	public Dialogue dialogue;

	public void intro()
	{
		FindObjectOfType<AudioManager>().Play("intro");
	}
	public void contextdialogue1()
	{
		FindObjectOfType<AudioManager>().Play("contextdialogue1");	
	}
	public void contextdialogue3()
	{
		FindObjectOfType<AudioManager>().Play("contextdialogue3");	
	}
}