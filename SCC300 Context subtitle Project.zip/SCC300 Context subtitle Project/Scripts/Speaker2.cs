﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Speaker2 : MonoBehaviour 
{
	public Dialogue dialogue;

	public void contextdialogue2()
	{
		FindObjectOfType<AudioManager2>().Play("contextdialogue2");	
	}
	public void contextdialogue4()
	{
		FindObjectOfType<AudioManager2>().Play("contextdialogue4");	
	}
}
