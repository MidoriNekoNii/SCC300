﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class EventManager : MonoBehaviour 
{
	#region Singleton
	private static EventManager _instance;
	public static EventManager Instance;
	#endregion

	public delegate void TriggerAction();
	public static event TriggerAction ActionTriggered;
	public int count = 0;
	public Speaker speaker;
	public Speaker2 speaker2;

    public AudioClip Intro;
	public AudioClip StaticDialogue1;
	public AudioClip StaticDialogue2;
	public AudioClip ContextDialogue1;
	public AudioClip ContextDialogue2;
	public AudioClip ContextDialogue3;
	public AudioClip ContextDialogue4;

    public DialogueSystem dialogueManager1;
    public DialogueSystem dialogueManager2;

	public TextMeshProUGUI subtitle0;
	public TextMeshProUGUI subtitle1;
	public TextMeshProUGUI subtitle2;

    void start()
	{

	}

    // Update is called once per frame
    void Update()
    {
        TriggerSpeakerPos();

        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
			DialogueSystem.Instance.BeginDialogue(Intro, 1, subtitle0);
			//DialogueSystem.Instance.BeginDialogue(Intro, 1, subtitle2);
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
			DialogueSystem.Instance.BeginDialogue(StaticDialogue1, 1, subtitle0);
        }
		if (Input.GetKeyDown(KeyCode.Alpha3))
		{
			DialogueSystem.Instance.BeginDialogue(StaticDialogue2, 1, subtitle0);
		}
		if (Input.GetKeyDown(KeyCode.F))
		{
			dialogueManager1.BeginDialogue(ContextDialogue1, 2, subtitle1);
			speaker.contextdialogue1();
			dialogueManager2.BeginDialogue(ContextDialogue2, 1, subtitle2);
			speaker2.contextdialogue2();
		}
		if (Input.GetKeyDown(KeyCode.R))
		{
			dialogueManager1.BeginDialogue(ContextDialogue3, 2, subtitle1);
			speaker.contextdialogue3();
			dialogueManager2.BeginDialogue(ContextDialogue4, 2, subtitle2);
			speaker2.contextdialogue4();
		}
    }
		
	public void TriggerSpeakerPos()
	{
		if (Input.GetKeyDown(KeyCode.Alpha0)) 
		{
			if(ActionTriggered != null)
			{
				ActionTriggered();
			}
		}
	}
}