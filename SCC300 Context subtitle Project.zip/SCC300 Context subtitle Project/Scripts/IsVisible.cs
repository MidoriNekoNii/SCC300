﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Attach this script to a GameObject with a Renderer component attached
//If the GameObject is visible to the camera, the message is output to the console

using UnityEngine;

public class IsVisible : MonoBehaviour
{
    Renderer m_Renderer;

	public bool visible = false;

	public bool Visible
	{
		get{ return visible; }
		set
		{
			visible = value;
		}
	}

    // Use this for initialization
    void Start()
    {
        m_Renderer = GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
		if (m_Renderer.isVisible) {
			Visible = true;
		} 
		else 
		{
			Visible = false;
		} 
    }
}
