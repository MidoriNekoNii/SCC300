﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OffscreenIndicator : MonoBehaviour 
{
	private Vector3 centerOfScreen = new Vector3(Screen.width, Screen.height, 0) / 2;
	public Image OnScreenSprite;
	public Image OnScreenSprite2;
    //public RawImage OffScreenSprite;
    public Image OffScreenSprite;
    //public RawImage OffScreenSprite2;
    public Image OffScreenSprite2;
    public GameObject speaker1;
	public GameObject speaker2;
	private bool audioPlaying = false;
	private bool audioPlaying2 = false;
	public AudioManager am;
	public AudioManager2 am2;
    public Camera HMD;

	public IsVisible visiblity1;
	public IsVisible visiblity2;

	private bool isSpeaker1Visible;
	private bool isSpeaker2Visible;

	private Vector3 speakerPosition;
	private Vector3 speakerPosition2;
    private Vector3 offscreenIndicatorPos;
    private Vector3 offscreenIndicatorPos2;


    public Vector3 SpeakerPosition
	{
		get{ return speakerPosition; }
	}

	public Vector3 SpeakerPosition2
	{
		get{ return speakerPosition2; }
	}

    public Vector3 OffscreenIndicatorPos
    {
        get{ return offscreenIndicatorPos; }
    }

    public Vector3 OffscreenIndicatorPos2
    {
        get { return offscreenIndicatorPos2; }
    }

    // Use this for initialization
    void Start() 
	{
		disableSprite1();
		disableSprite2();

    }
	
	// Update is called once per frame
	void Update() 
	{
		check();
		active();
    }

	void disableSprite1()
	{
		OffScreenSprite.enabled = false;
		OnScreenSprite.enabled = false;
	}

	void disableSprite2()
	{
		OffScreenSprite2.enabled = false;
		OnScreenSprite2.enabled = false;
	}

	void check()
	{
		audioPlaying = am.AudioPlaying;
		audioPlaying2 = am2.AudioPlaying;
	}

	void active()
	{	
		if (audioPlaying == true) 
		{
			paint();
			//Debug.Log ("Playing...");
		}
		else
		{
			disableSprite1();
		}
		if (audioPlaying2 == true)
		{
			paint2();
		}	
		else
		{
			disableSprite2();
			//Debug.Log ("Stopped.");
		}
	}

	/// <summary>
	/// Split the paint function
	/// </summary>
	/// 

	//Onscreen indicator
	void paint()
	{
        OffScreenSprite.enabled = false;
		//OnScreenSprite.enabled = true;
        speakerPosition = HMD.WorldToScreenPoint(speaker1.transform.position);
		isSpeaker1Visible = visiblity1.Visible;
		onScreen(offscreenIndicatorPos, OnScreenSprite, OffScreenSprite, speakerPosition, isSpeaker1Visible);
        offscreenIndicatorPos = OffScreenSprite.transform.localPosition - centerOfScreen;
    }

	void paint2()
	{
        OffScreenSprite2.enabled = false;
		//OnScreenSprite2.enabled = true;
        speakerPosition2 = HMD.WorldToScreenPoint(speaker2.transform.position);
		isSpeaker2Visible = visiblity2.Visible;    
		onScreen(offscreenIndicatorPos2, OnScreenSprite2, OffScreenSprite2, speakerPosition2, isSpeaker2Visible);
        offscreenIndicatorPos2 = OffScreenSprite2.transform.localPosition - centerOfScreen;
    }



	void onScreen(Vector3 pos, Image Sprite, Image offSprite, Vector3 screenPoint, bool isVisible)
	{
        //Check if speaker object is in front AND within the monitor screen
		if (isVisible == true) 
		{
            // get an index to use for our sprite, based on the objects index in the objects list 
            // we should make an objectpool manager
            //Put indicator on speaker object
            //Sprite.transform.localPosition = screenPoint;
        }
		else 
		{
            offScreen(pos, offSprite, Sprite, screenPoint);
        }
	}

	//Offscreen indicator
	void offScreen(Vector3 pos, Image offSprite, Image Sprite, Vector3 screenPoint)
	{
		Sprite.enabled = false;
		offSprite.enabled = true;

		if (screenPoint.z < 0) 
		{
			screenPoint *= -1; //When speaker is behind, flip screen position for indictor
		}

		Vector3 centerOfScreen = new Vector3 (Screen.width, Screen.height, 0)/2;

		screenPoint -= centerOfScreen; //Make center of screen 0,0

		float angle = Mathf.Atan2 (screenPoint.y, screenPoint.x);
		angle -= 90 * Mathf.Deg2Rad;
		float cos = Mathf.Cos(angle);
		float sin = -Mathf.Sin(angle);

		screenPoint = centerOfScreen + new Vector3 (sin * 150, cos * 150, 0);

		float m = cos / sin; //y = mx + b

		Vector3 boundsOfScreen = centerOfScreen * 0.85f;

		//Check if out of bounds y
		if (cos > 0) 
		{
			screenPoint = new Vector3 (boundsOfScreen.y / m, boundsOfScreen.y, 0);
		} 
		else 
		{
			screenPoint = new Vector3 (-boundsOfScreen.y / m, -boundsOfScreen.y, 0);
		}
			
		//Check if out of bounds x
		if (screenPoint.x > boundsOfScreen.x) 
		{
			screenPoint = new Vector3 (boundsOfScreen.x, boundsOfScreen.x * m, 0);
		} 
		else if (screenPoint.x < -boundsOfScreen.x) 
		{
			screenPoint = new Vector3 (-boundsOfScreen.x, -boundsOfScreen.x * m, 0);
		}
		screenPoint += centerOfScreen;
		offSprite.transform.localPosition = screenPoint;
    }
}