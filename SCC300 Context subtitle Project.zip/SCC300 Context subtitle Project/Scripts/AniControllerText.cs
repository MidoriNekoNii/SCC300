﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AniControllerText : MonoBehaviour {

	public Animator ani;
	
	// Use this for initialization
	void Start () 
	{
		ani = GetComponent<Animator>();
		ani.Play("Welcome_Sub");
	}
	
	// Update is called once per frame
	void Update () 
	{
		int layerMask = 1 << 8;
		layerMask = ~layerMask;
		RaycastHit hit;

		Vector3 fwd = transform.TransformDirection(Vector3.forward);
		if (Physics.Raycast (transform.position, fwd, out hit, Mathf.Infinity, layerMask))
		{
			ani.Play("Welcome_Fade_Out");
			Debug.DrawRay(transform.position, fwd * hit.distance, Color.green);
			//Debug.Log("Did hit");
		}
		else
		{
			ani.Play("Welcome_Fade_In");
			Debug.DrawRay(transform.position, fwd * 1000, Color.white);
			//Debug.Log("Did not hit");
		}
	}
}
