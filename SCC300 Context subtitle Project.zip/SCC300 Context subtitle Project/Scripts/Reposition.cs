﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Reposition : MonoBehaviour 
{
	public void OnEnable()
	{
		EventManager.ActionTriggered += RepositionSpeaker;
	}

	public void OnDisable()
	{
		EventManager.ActionTriggered -= RepositionSpeaker;
	}
	
	public void RepositionSpeaker()
	{
		Vector3 position = transform.position;
		position.x = Random.Range(2.0f, 12.0f);
		position.y = Random.Range(98.0f, 100.0f);
		position.z = Random.Range(-10.0f, 9.0f);
		transform.position = position;
	}
}